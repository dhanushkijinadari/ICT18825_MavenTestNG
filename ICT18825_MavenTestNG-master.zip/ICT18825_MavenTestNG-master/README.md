# ICT18825_MavenTestNG
This Repo is for save and maintain the Assignment given in the module called Emerging Technology

#Git_Repo_Link
https://github.com/dhanushkijinadari/ICT18825_MavenTestNG.git
